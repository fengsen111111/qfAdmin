<script setup>
  import { ref, inject, reactive } from 'vue'
  let formStateThree = ref({})//营销活动信息所有数据

</script>


<template>
  <div style="overflow: auto;height: 100%;">
    <div>
      <a-form :model="formStateThree" :label-col="{style: {width: '120px'}}" :wrapper-col="{sapn:14}">
        <div
          style="background-color: #f5F5F5;padding:10px 20px;width: 100%;margin-bottom: 20px;font-weight: bold;">
          一分钱秒杀活动</div>
        <a-row>
          <a-col :span="13">
            <a-form-item label="选择规格">
              <div style="display: flex;height: 32px;align-items: center;">
                <a-select ref="select" value="jack" style="width: 300px" placeholder="选择规格">
                  <a-select-option value="jack">Jack</a-select-option>
                  <a-select-option value="lucy">Lucy</a-select-option>
                  <a-select-option value="Yiminghe">yiminghe</a-select-option>
                </a-select>
                <div
                  style="padding: 5px;background-color: #1890ff;color: white;border-radius:5px;margin-right: 10px;">
                  确认参加</div>
                <div style="background-color: #f97425;color: white;padding: 5px 20px;border-radius: 5px">重置</div>
              </div>
            </a-form-item>
          </a-col>
          <a-col :span="7">
            <a-form-item label="活动时间">
              <a-range-picker v-model:value="formStateThree.time" style="width: 300px;" />
            </a-form-item>
          </a-col>
          <a-col :span="13">
            <div style="display: flex;align-items: center;margin-bottom: 20px;">
              <label
                style="padding: 5px;background-color: #83c2ff;color: white;border-radius:5px;margin-right: 10px;margin-left: 2.5vw;">
                可乐味 X</label>
              <div style="margin: 0 10px;">：</div>
              <div style="background-color: #f5F5F5;padding: 5px;border-radius:5px;margin-right: 10px;">500ml*1
                X</div>
              <div style="background-color: #f5F5F5;padding: 5px;border-radius:5px;margin-right: 10px;">500ml*6
                X</div>
              <div style="background-color: #f5F5F5;padding: 5px;border-radius:5px;margin-right: 10px;">500ml*12
                X</div>
            </div>
          </a-col>
          <a-col :span="7">
            <a-form-item label="适用人群">
              <a-select ref="select" value="jack" placeholder="适用人群" style="width: 300px;">
                <a-select-option value="jack">Jack</a-select-option>
                <a-select-option value="lucy">Lucy</a-select-option>
                <a-select-option value="Yiminghe">yiminghe</a-select-option>
              </a-select>
            </a-form-item>
          </a-col>
          <a-col :span="13">
            <div style="display: flex;align-items: center;margin-bottom: 20px;">
              <label
                style="padding: 5px;background-color: #83c2ff;color: white;border-radius:5px;margin-right: 10px;margin-left: 2.5vw;">
                可乐味 X</label>
              <div style="margin: 0 10px;">：</div>
              <div style="background-color: #f5F5F5;padding: 5px;border-radius:5px;margin-right: 10px;">500ml*1
                X</div>
            </div>
          </a-col>
          <a-col :span="13">
            <div style="display: flex;align-items: center;margin-bottom: 20px;">
              <label
                style="padding: 5px;background-color: #83c2ff;color: white;border-radius:5px;margin-right: 10px;margin-left: 2.5vw;">
                可乐味 X</label>
              <div style="margin: 0 10px;">：</div>
              <div style="background-color: #f5F5F5;padding: 5px;border-radius:5px;margin-right: 10px;">500ml*1
                X</div>
              <div style="background-color: #f5F5F5;padding: 5px;border-radius:5px;margin-right: 10px;">500ml*6
                X</div>
              <div style="background-color: #f5F5F5;padding: 5px;border-radius:5px;margin-right: 10px;">500ml*12
                X</div>
            </div>
          </a-col>
          <a-col :span="13">
            <div style="display: flex;align-items: center;margin-bottom: 20px;">
              <label
                style="padding: 5px;background-color: #83c2ff;color: white;border-radius:5px;margin-right: 10px;margin-left: 2.5vw;">
                可乐味 X</label>
              <div style="margin: 0 10px;">：</div>
              <div style="background-color: #f5F5F5;padding: 5px;border-radius:5px;margin-right: 10px;">500ml*1
                X</div>
              <div style="background-color: #f5F5F5;padding: 5px;border-radius:5px;margin-right: 10px;">500ml*6
                X</div>
            </div>
          </a-col>
        </a-row>
        <div
          style="background-color: #f5F5F5;padding:10px 20px;width: 100%;margin-bottom: 20px;font-weight: bold;">
          限时秒杀活动</div>
        <a-row>
          <a-col :span="13">
            <a-form-item label="活动时间">
              <a-range-picker v-model:value="formStateThree.time" style="width: 300px;" />
            </a-form-item>
          </a-col>
          <a-col :span="13">
            <a-form-item label="秒杀时长">
              <a-time-picker v-model:value="formStateThree.time2" style="width: 300px;"/>
            </a-form-item>
          </a-col>
          <a-col :span="13">
            <a-form-item label="开始时间">
              <a-time-picker v-model:value="formStateThree.time3" style="width: 300px;"/>
            </a-form-item>
          </a-col>
          <a-col :span="13">
            <a-form-item label="折扣比例">
              <a-input v-model:value="formStateThree.name" placeholder="请输入折扣比例" style="width: 300px;" />
            </a-form-item>
          </a-col>
          <a-col :span="13">
            <a-form-item label="选择规格">
              <div style="display: flex;height: 32px;align-items: center;">
                <a-select ref="select" value="jack" style="width: 300px" placeholder="选择规格">
                  <a-select-option value="jack">Jack</a-select-option>
                  <a-select-option value="lucy">Lucy</a-select-option>
                  <a-select-option value="Yiminghe">yiminghe</a-select-option>
                </a-select>
                <div
                  style="padding: 5px;background-color: #1890ff;color: white;border-radius:5px;margin-right: 10px;">
                  确认参加</div>
                <div style="background-color: #f97425;color: white;padding: 5px 20px;border-radius: 5px">重置</div>
              </div>
            </a-form-item>
          </a-col>
          <a-col :span="13">
            <div style="display: flex;align-items: center;margin-bottom: 20px;">
              <label
                style="padding: 5px;background-color: #83c2ff;color: white;border-radius:5px;margin-right: 10px;margin-left: 2.5vw;">
                可乐味 X</label>
              <div style="margin: 0 10px;">：</div>
              <div style="background-color: #f5F5F5;padding: 5px;border-radius:5px;margin-right: 10px;">500ml*1
                X</div>
            </div>
          </a-col>
          <a-col :span="13">
            <div style="display: flex;align-items: center;margin-bottom: 20px;">
              <label
                style="padding: 5px;background-color: #83c2ff;color: white;border-radius:5px;margin-right: 10px;margin-left: 2.5vw;">
                可乐味 X</label>
              <div style="margin: 0 10px;">：</div>
              <div style="background-color: #f5F5F5;padding: 5px;border-radius:5px;margin-right: 10px;">500ml*1
                X</div>
              <div style="background-color: #f5F5F5;padding: 5px;border-radius:5px;margin-right: 10px;">500ml*6
                X</div>
              <div style="background-color: #f5F5F5;padding: 5px;border-radius:5px;margin-right: 10px;">500ml*12
                X</div>
            </div>
          </a-col>
          <a-col :span="13">
            <div style="display: flex;align-items: center;margin-bottom: 20px;">
              <label
                style="padding: 5px;background-color: #83c2ff;color: white;border-radius:5px;margin-right: 10px;margin-left: 2.5vw;">
                可乐味 X</label>
              <div style="margin: 0 10px;">：</div>
              <div style="background-color: #f5F5F5;padding: 5px;border-radius:5px;margin-right: 10px;">500ml*1
                X</div>
              <div style="background-color: #f5F5F5;padding: 5px;border-radius:5px;margin-right: 10px;">500ml*6
                X</div>
            </div>
          </a-col>
        </a-row>
      </a-form>
    </div>
  </div>
</template>


<style>
  .table_one {
    border-collapse: collapse;
    border: 1px solid rgb(140 140 140);
    font-family: sans-serif;
    font-size: 0.8rem;
    letter-spacing: 1px;
    text-align: center;
  }

  .table_two {
    border-collapse: collapse;
    border: 2px solid #1890ff;
    font-family: sans-serif;
    font-size: 0.8rem;
    letter-spacing: 1px;
    text-align: center;
  }



  .table_one th,
  td {
    border: 1px solid #e9e9e9;
    padding: 10px 60px;
  }

  .table_two th,
  td {
    border: 1px solid #e9e9e9;
    padding: 10px 20px;
  }

  td:last-of-type {
    text-align: center;
  }

  .ant-tabs-card>.ant-tabs-nav .ant-tabs-tab-active,
  .ant-tabs-card>div>.ant-tabs-nav .ant-tabs-tab-active {
    background: #1890ff !important;
    color: white !important;
  }


  .ant-tabs-tab.ant-tabs-tab-active .ant-tabs-tab-btn {
    text-shadow: 0 0 0.25px currentcolor;
    color: white !important;
  }

  .ant-tabs-tab {
    position: relative;
    display: inline-flex;
    align-items: center;
    padding: 12px 0;
    font-size: 14px;
    background: transparent;
    border: 0;
    outline: none;
    cursor: pointer;
    margin-right: 20px !important;
    background: white !important;
    font-weight: bold;
    border: 2px solid #f5f5f5 !important;
    border-radius: 10px 10px 0px 0px !important;
  }
</style>