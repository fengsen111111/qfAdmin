import Card from './card.vue'
import Bar from './bar.vue'
import Bars from './bars.vue'
import Line from './line.vue'
import Pie from './pie.vue'
import Rose from './rose.vue'

export const EchartsComponents = {
    Card, Bar, Bars, Line, Pie, Rose
};